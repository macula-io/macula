-module(macula_membership).

-export([]).
