-module(macula_discovery).

-export([]).
