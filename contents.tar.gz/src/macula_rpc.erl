-module(macula_rpc).

-export([]).
