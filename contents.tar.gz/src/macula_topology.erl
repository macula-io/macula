-module(macula_topology).

-export([]).
