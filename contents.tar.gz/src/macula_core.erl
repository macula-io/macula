-module(macula_core).

-export([]).
