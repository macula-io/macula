-module(macula_protocol).

-export([]).
