-module(macula_security).

-export([]).
