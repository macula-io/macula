-module(macula_pubsub).

-export([]).
